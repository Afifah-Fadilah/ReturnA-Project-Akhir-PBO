/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sesi;   
/**
 *
 * @author afifa
 */
//Class untuk memanajemen id pengguna persesi
public class SessionManager {
      public static int idPelanggan; // Variabel statis untuk menyimpan id pengguna selama sesi
      
}
